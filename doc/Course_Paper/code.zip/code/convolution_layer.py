#!/usr/bin/env python

import numpy as np
import theano
from theano import tensor as T
import itertools

class convolution_layer:
  _ids = itertools.count(1)

  def __init__(self, X_var, X_values, input_shape, stride, depth, trng, batch_size = None, dropout_prob = None, W = None, b = None):
    self.layer_id = self._ids.next()

    self.W    = None
    self.b    = None
    self.X    = X_var
    self.filter_shape = (depth, input_shape[0], stride, stride)
    self.output_shape = (depth, input_shape[1], input_shape[2])
    self.border_shift = (stride - 1) // 2

    self.initialize_parameters(W, b, fan_in = np.prod(input_shape), fan_out = depth * input_shape[1] * input_shape[2], W_shape = self.filter_shape, trng = trng)
    self.reset_gradient_sums()
    self.reset_gradient_velocities()

    convolution = T.nnet.conv.conv2d(input = X_values, filters = self.W,
                                     filter_shape = self.filter_shape, subsample = (1,1), border_mode = 'full')[:, :,
                                     self.border_shift: input_shape[1] + self.border_shift, self.border_shift: input_shape[2] + self.border_shift]

    self.output = convolution + self.b.dimshuffle('x', 0, 'x', 'x')

    if dropout_prob > 0.0:
      if batch_size == None:
        batch_size = self.num_training_examples
      self.dropout_mask  = trng.binomial(n = 1, p = 1 - dropout_prob, size = np.insert(input_shape, 0, batch_size)) / dropout_prob
      self.masked_output = T.nnet.conv.conv2d(input = self.X * self.dropout_mask[:self.X.shape[0]], filters = self.W, filter_shape = self.filter_shape, subsample = (1,1), border_mode = 'full')[:, :, self.border_shift: input_shape[1] + self.border_shift, self.border_shift: input_shape[2] + self.border_shift]
    else:
        self.masked_output = T.nnet.conv.conv2d(input = self.X, filters = self.W, subsample = (1,1), border_mode = 'full')[:, :,
                                                self.border_shift: input_shape[1] + self.border_shift, self.border_shift: input_shape[2] + self.border_shift]

    print 'Convolution Layer %i initialized' % (self.layer_id)

  #######################################################################################################################

  def configure_training_environment(self, cost_function, learning_rate = 1e-3, reg_strength = 1e-4, rms_decay_rate = 0.9,
                                     rms_injection_rate = None, use_nesterov_momentum = False, momentum_decay_rate = 0.9):

    g_W = T.grad(cost=cost_function, wrt=self.W)
    g_b = T.grad(cost=cost_function, wrt=self.b)

    if use_nesterov_momentum:
      W_update = self.W_gradient_velocity * momentum_decay_rate**2 - (1 + momentum_decay_rate) * learning_rate * g_W
      b_update = self.b_gradient_velocity * momentum_decay_rate**2 - (1 + momentum_decay_rate) * learning_rate * g_b
    else:
      W_update = - learning_rate * g_W
      b_update = - learning_rate * g_b

    self.parameter_updates = [(self.W, self.W + W_update / T.sqrt(self.W_gradient_sums + T.sqr(g_W)) - reg_strength * self.W),
                              (self.b, self.b + b_update / T.sqrt(self.b_gradient_sums + T.sqr(g_b)) - reg_strength * self.b),
                              (self.W_gradient_sums, rms_decay_rate * self.W_gradient_sums + rms_injection_rate * T.sqr(W_update / learning_rate)),
                              (self.b_gradient_sums, rms_decay_rate * self.b_gradient_sums + rms_injection_rate * T.sqr(b_update / learning_rate))]

    if use_nesterov_momentum:
      self.parameter_updates.append((self.W_gradient_velocity, momentum_decay_rate * self.W_gradient_velocity - learning_rate * g_W))
      self.parameter_updates.append((self.b_gradient_velocity, momentum_decay_rate * self.b_gradient_velocity - learning_rate * g_b))

  #######################################################################################################################

  def initialize_parameters(self, W, b, fan_in, fan_out, W_shape, trng):

    if self.W == None:
      if W == None:
          self.W = theano.shared(trng.uniform(low = - np.sqrt(6. / (fan_in + fan_out)),
                                                 high = np.sqrt(6. / (fan_in + fan_out)),
                                                 size = W_shape).eval(), borrow=True)
      else:
        self.W = theano.shared(W, borrow=True)

    if self.b == None:
      if b == None:
        self.b = theano.shared(np.zeros((W_shape[0])), borrow=True)
      else:
        self.b = theano.shared(b, borrow=True)

  #######################################################################################################################

  def reset_gradient_sums(self):
    self.W_gradient_sums = theano.shared(1e-8 * np.ones(self.filter_shape), borrow=True)
    self.b_gradient_sums = theano.shared(1e-8 * np.ones((self.filter_shape[0],)), borrow=True)

  #######################################################################################################################

  def reset_gradient_velocities(self):
    self.W_gradient_velocity = theano.shared(np.zeros(self.filter_shape), borrow=True)
    self.b_gradient_velocity = theano.shared(np.zeros((self.filter_shape[0],)), borrow = True)


