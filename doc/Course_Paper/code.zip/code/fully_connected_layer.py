#!/usr/bin/env python

import numpy as np
import theano
from theano import tensor as T
import itertools

class fully_connected_layer:
  _ids = itertools.count(1)

  def __init__(self, X_var, X_values, input_shape, num_neurons, trng, batch_size = None, dropout_prob = None, W = None, b = None):
    self.layer_id = self._ids.next()

    self.W    = None
    self.b    = None
    self.X    = X_var.flatten(2)
    self.X_values = X_values.flatten(2)
    self.num_features = np.prod(input_shape)
    self.num_output_neurons = num_neurons

    self.initialize_parameters(W, b, trng)
    self.reset_gradient_sums(W_shape = (np.prod(input_shape), num_neurons))
    self.reset_gradient_velocities(W_shape = (np.prod(input_shape), num_neurons))

    self.output = T.dot(self.X_values, self.W) + self.b
    self.output_shape = num_neurons

    if dropout_prob > 0.0:
      if batch_size == None:
        print 'No batch size given. This will slow down performance'
        batch_size, _ = self.X_values.eval().shape
      self.dropout_mask  = trng.binomial(n = 1, p = 1 - dropout_prob, size=(batch_size, np.prod(input_shape))) / dropout_prob
      self.masked_output = T.dot(self.X * self.dropout_mask[:self.X.shape[0]], self.W) + self.b
    else:
      self.masked_output = T.dot(self.X, self.W) + self.b

    print 'Fully Connected Layer %i initialized' % (self.layer_id)
    
  #######################################################################################################################

  def configure_training_environment(self, cost_function, learning_rate = 1e-3, reg_strength = 1e-4, rms_decay_rate = 0.9,
                                     rms_injection_rate = None, use_nesterov_momentum = False, momentum_decay_rate = 0.9):

    g_W = T.grad(cost=cost_function, wrt=self.W)
    g_b = T.grad(cost=cost_function, wrt=self.b)

    if use_nesterov_momentum:
      W_update = self.W_gradient_velocity * momentum_decay_rate**2 - (1 + momentum_decay_rate) * learning_rate * g_W
      b_update = self.b_gradient_velocity * momentum_decay_rate**2 - (1 + momentum_decay_rate) * learning_rate * g_b
    else:
      W_update = - learning_rate * g_W
      b_update = - learning_rate * g_b

    self.parameter_updates = [(self.W, self.W + W_update / T.sqrt(self.W_gradient_sums + T.sqr(g_W)) - reg_strength * self.W),
                              (self.b, self.b + b_update / T.sqrt(self.b_gradient_sums + T.sqr(g_b)) - reg_strength * self.b),
                              (self.W_gradient_sums, rms_decay_rate * self.W_gradient_sums + rms_injection_rate * T.sqr(W_update / learning_rate)),
                              (self.b_gradient_sums, rms_decay_rate * self.b_gradient_sums + rms_injection_rate * T.sqr(b_update / learning_rate))]

    if use_nesterov_momentum:
      self.parameter_updates.append((self.W_gradient_velocity, momentum_decay_rate * self.W_gradient_velocity - learning_rate * g_W))
      self.parameter_updates.append((self.b_gradient_velocity, momentum_decay_rate * self.b_gradient_velocity - learning_rate * g_b))

  #######################################################################################################################

  def initialize_parameters(self, W, b, trng):

    if self.W == None:
      if W == None:
        self.W = theano.shared(trng.uniform(low = - np.sqrt(6. / (self.num_features + self.num_output_neurons)),
                                                 high = np.sqrt(6. / (self.num_features + self.num_output_neurons)),
                                                 size = (self.num_features, self.num_output_neurons)).eval(), borrow=True)
      else:
        self.W = theano.shared(W, borrow=True)

    if self.b == None:
      if b == None:
        self.b = theano.shared(np.zeros((self.num_output_neurons,)), borrow=True)
      else:
        self.b = theano.shared(b, borrow=True)

  #######################################################################################################################

  def predict(self, X_test):
    return T.dot(X_test, self.W) + self.b

  #######################################################################################################################

  def reset_gradient_sums(self, W_shape):
    self.W_gradient_sums = theano.shared(1e-8 * np.ones(W_shape), borrow=True)
    self.b_gradient_sums = theano.shared(1e-8 * np.ones((W_shape[1],)), borrow=True)

  #######################################################################################################################

  def reset_gradient_velocities(self, W_shape):
    self.W_gradient_velocity = theano.shared(np.zeros(W_shape), borrow=True)
    self.b_gradient_velocity = theano.shared(np.zeros((W_shape[1],)), borrow = True)


